/****************************************************************
* Name
* ECE3724 - Section __
* Lab #9 - lab9.c
* Date
*****************************************************************
* Simple I2C exercises using an LC512 EEPROM
* Adapted 2024 by Peter Loux Sr, from the original i2c_eeprom.c
* by Robert B. Reese, Bryan A. Jones, and J. W. Bruce (2008)
* Mississippi State University, ECE3724 class usage only 
****************************************************************/

#include "pic24_all.h"
#include <stdio.h>

// control bytes
#define READ 0x00
#define WRITE 0x00

// acknowledge bit
#define NAK (1)
#define ACK (0)

uint8_t readOneByteCurrentAddress(void);
uint8_t readOneByteSpecificAddress(uint16_t u16_address);
void writeOneByteSpecificAddress(uint16_t u16_address, uint8_t u8_byte);


uint16_t getAddress() {
	char buf[16];
	uint16_t u16_val;
	outString("Enter an address in hex (format @@@@): ");
	inStringEcho(buf,16);
	sscanf(buf,"%x",&u16_val);
	return(u16_val);
}

uint8_t getByte() {
	char buf[16];
	uint16_t u16_val;
	outString("Enter a byte in hex (format @@): ");
	inStringEcho(buf,16);
	sscanf(buf,"%x",&u16_val);
	return(u16_val & 0xFF);
}

uint8_t readOneByteCurrentAddress(void) {
	uint8_t val;		// holds the byte read
	startI2C1();		// start I2C transaction
	putI2C1(READ);		// send the control byte for a read
	val = getI2C1(NAK); // read the character, send NAK to indicate end of read
	stopI2C1();         // end I2Cthe transaction
	return(val);        // return the byte that was read
}

uint8_t  readOneByteSpecificAddress(uint16_t u16_address) {

	
	return 0;			// return the byte read
}

void writeOneByteSpecificAddress(uint16_t u16_address, uint8_t u8_byte) {

	
}

int main (void) {
	configBasic(HELLO_MSG);
	char c;
	uint16_t u16_address;
	uint8_t u8_byte, u8_byte2;
	CONFIG_RB14_AS_DIG_OUTPUT();
	configI2C1(400);             // configure I2C for 400 KHz
	while (1) {
		outString("1. Read 1 byte from current address\n");
		outString("2. Read 1 byte from specific address\n");
		outString("3. Write (and verify) 1 byte from specific address\n");
		outString("Enter menu choice: ");
		c = inCharEcho();
		outChar('\n');
		if (c == '1') {
			u8_byte = readOneByteCurrentAddress();
			printf("\nThe byte read from the current address is 0x%02x ('%c')\n", u8_byte, u8_byte);
		} 
		else if (c == '2') {
			u16_address = getAddress();
			u8_byte = readOneByteSpecificAddress(u16_address);
			printf("\nThe byte read from address: 0x%04x is 0x%02x ('%c')\n", u16_address, u8_byte, u8_byte);
		} 
		else if (c == '3') {
			u16_address = getAddress();
			u8_byte = getByte();
			writeOneByteSpecificAddress(u16_address, u8_byte);
			DELAY_MS(20);	// delay to ensure that write finishes
			u8_byte2 = readOneByteSpecificAddress(u16_address);
			if (u8_byte == u8_byte2) {
				printf("\nThe write of byte 0x%02x ('%c') to address: 0x%04x succeeded!\n", u8_byte, u8_byte, u16_address);
			} 
			else  {
				printf("\nThe write of byte 0x%02x ('%c') to address: 0x%04x FAILED, read byte: 0x%02x ('%c') after write!\n",u8_byte,u8_byte, u16_address, u8_byte2, u8_byte2);
			}
		}
	}
	return 0;
}	
