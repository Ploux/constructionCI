/*
 * "Copyright (c) 2008 Robert B. Reese, Bryan A. Jones, J. W. Bruce ("AUTHORS")"
 * All rights reserved.
 * (R. Reese, reese_AT_ece.msstate.edu, Mississippi State University)
 * (B. A. Jones, bjones_AT_ece.msstate.edu, Mississippi State University)
 * (J. W. Bruce, jwbruce_AT_ece.msstate.edu, Mississippi State University)
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the authors appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE "AUTHORS" BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE "AUTHORS"
 * HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE "AUTHORS" SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE "AUTHORS" HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Please maintain this header in its entirety when copying/modifying
 * these files.
 *
 *
 */
#include "pic24_all.h"
#include <stdio.h>

/** \file
 Measures overflow time of the UART
*/


volatile uint8_t u8_TimerOverflow = 0;
//Interrupt Service Routine for Timer3
void _ISRFAST _T3Interrupt (void) {
  u8_TimerOverflow = 1;
  _T3IF = 0;    //clear the timer interrupt bit
}

void  configTimer3(void) {
  //ensure that Timer2,3 configured as separate timers.
  T2CONbits.T32 = 0;     // 32-bit mode off
  //T3CON set like this for documentation purposes.
  //could be replaced by T3CON = 0x0020
  T3CON = T3_OFF |T3_IDLE_CON | T3_GATE_OFF
          | T3_SOURCE_INT
          | T3_PS_1_8 ;  //results in T3CON= 0x0020
  PR3 = 0xFFFF;           //max periods
  TMR3  = 0;                       //clear timer3 value
  _T3IF = 0;                       //clear interrupt flag
  _T3IP = 1;                       //choose a priority
  _T3IE = 1;                       //enable the interrupt
  T3CONbits.TON = 0;               //ensure the timer is off
}

_PERSISTENT uint16_t u16_t3ticks;

int main (void) {
  configBasic(HELLO_MSG);

  
  CONFIG_RB14_AS_DIG_OUTPUT();
  CONFIG_RB2_AS_DIG_OUTPUT();
  _LATB2 = 1;
  configTimer3();
  if (u16_t3ticks != 0) {
    printf("UART overflow occurred, timer ticks is: %u\n",u16_t3ticks);
  }

  while (1) {
    T3CONbits.TON = 0;     //ensure the timer is off
    TMR3 = 0;               //zero the timer
    _LATB14 = 0;            //RB14 is low
    u8_TimerOverflow = 0;   //timer overflow semaphore is cleared
    u16_t3ticks = 0;
    printf("Enter character string.\n");
    inChar();               //get first character
    _LATB14 = 1;            //set RB14 high
    T3CONbits.TON = 1;     //start timer
    while (u8_TimerOverflow == 0 ) {
      //check UART overflow error flag
      if (U1STAbits.OERR) {
        //overflow occurred!!!
        T3CONbits.TON = 0;     //freeze timer by turning it off
        _LATB14 = 0;            //set RB14 low, RB14 pulse high time should be overflow time
        u16_t3ticks = TMR3;    //remember the number of ticks
        break;                 //break out of loop
      }
    }//end while(u8_TimerOverflow == 0)
    if (U1STAbits.OERR) {
      asm("reset"); //reset on overflow
     
    } else {
      //flush input buffer reading all available characters
      while (isCharReady1())  inChar();
      printf("UART overflow did not occur\n");
    }

  }
}//end main
