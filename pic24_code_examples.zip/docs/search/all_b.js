var searchData=
[
  ['mailbox',['MAILBOX',['../struct_m_a_i_l_b_o_x.html',1,'']]],
  ['main_5ft',['main_t',['../esos_8h.html#ae2a8610ad6ad5ea2114f2ebb65974ecc',1,'esos.h']]],
  ['max_5fnum_5fchild_5ftasks',['MAX_NUM_CHILD_TASKS',['../esos_8h.html#a83e8d97ef5684ebd1a15bd3e7c927b62',1,'esos.h']]],
  ['max_5fnum_5fxfer_5fvars',['MAX_NUM_XFER_VARS',['../data_xfer_impl_8h.html#a3d14a9fcd9a82c542d41517ceffcd61c',1,'dataXferImpl.h']]],
  ['microstick2',['MICROSTICK2',['../pic24__libconfig_8h.html#a907181d5d566808c0c9fea70cac1f515',1,'pic24_libconfig.h']]],
  ['ms_5fper_5fheartbeat',['MS_PER_HEARTBEAT',['../pic24__util_8c.html#a6117bd5a7ac4d5eada9969f45d1544fa',1,'pic24_util.c']]],
  ['msb',['MSB',['../all__generic_8h.html#a9c836be4f9864747a0b7cbc120b07454',1,'all_generic.h']]],
  ['msn',['MSN',['../union_u_i_n_t8.html#af39eaaed6ff8d91832c1a1346e29d66d',1,'UINT8']]],
  ['mstou16ticks',['msToU16Ticks',['../pic24__timer_8c.html#aa2b459a5ab40167228c2ab6369fee878',1,'msToU16Ticks(uint16_t u16_ms, uint16_t u16_pre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#aa2b459a5ab40167228c2ab6369fee878',1,'msToU16Ticks(uint16_t u16_ms, uint16_t u16_pre):&#160;pic24_timer.c']]]
];
