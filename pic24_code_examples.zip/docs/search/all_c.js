var searchData=
[
  ['nop',['NOP',['../pic24__chip_8h.html#ad99fda6bb7696991797c925f968234b9',1,'pic24_chip.h']]],
  ['notifyoftimeout',['notifyOfTimeout',['../data_xfer_impl_8c.html#ae347b3bdd40465fab8ba2fb3975a74d4',1,'notifyOfTimeout():&#160;dataXferImpl.c'],['../data_xfer_impl_8h.html#ae347b3bdd40465fab8ba2fb3975a74d4',1,'notifyOfTimeout():&#160;dataXferImpl.c']]],
  ['nullidx',['NULLIDX',['../all__generic_8h.html#ab4f2d7d56f743d68fcf1d6eb8a4abac2',1,'all_generic.h']]],
  ['nullptr',['NULLPTR',['../all__generic_8h.html#a3ef7eab8cd0e570b6586628cc9d5ccab',1,'all_generic.h']]],
  ['num_5fecan_5fmods',['NUM_ECAN_MODS',['../pic24__chip_8h.html#a34b4441eee9be6efbf733ca5a0146b6a',1,'pic24_chip.h']]],
  ['num_5ferror_5fcodes',['NUM_ERROR_CODES',['../data_xfer_impl_8h.html#a2c3b22fc7b885c6bc66b8b99150c72a7',1,'dataXferImpl.h']]],
  ['num_5fi2c_5fmods',['NUM_I2C_MODS',['../pic24__chip_8h.html#a8b4f64c4586ceb2130072d768fcfee2a',1,'pic24_chip.h']]],
  ['num_5fspi_5fmods',['NUM_SPI_MODS',['../pic24__chip_8h.html#a5829648ac066cf8c0863dee06896ed18',1,'pic24_chip.h']]],
  ['num_5fuart_5fmods',['NUM_UART_MODS',['../pic24__chip_8h.html#afcc899635b779f2708042a7ba5f0ab47',1,'pic24_chip.h']]],
  ['num_5fxfer_5fvars',['NUM_XFER_VARS',['../data_xfer_impl_8h.html#ad5c4dcae370b21267b8b9e729d6f0a12',1,'dataXferImpl.h']]]
];
