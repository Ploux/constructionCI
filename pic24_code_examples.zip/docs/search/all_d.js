var searchData=
[
  ['ok',['OK',['../all__generic_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'all_generic.h']]],
  ['open',['open',['../pic24__stdio__uart_8c.html#ac3d5e06fed3d193ae2f25c6ca25c6256',1,'pic24_stdio_uart.c']]],
  ['osc_5fsel_5fbits',['OSC_SEL_BITS',['../pic24__clockfreq_8h.html#a48cc82e45d755fb067ec21ad11b97f03',1,'pic24_clockfreq.h']]],
  ['outchar',['outChar',['../pic24__serial_8c.html#a6b92bf3594430f822e6e1155c434a39b',1,'outChar(uint8_t u8_c):&#160;pic24_serial.c'],['../data_xfer_8h.html#aa9356090c952defa540ee6173793a15e',1,'outChar(uint8_t c):&#160;pic24_serial.c'],['../pic24__serial_8h.html#a6b92bf3594430f822e6e1155c434a39b',1,'outChar(uint8_t u8_c):&#160;pic24_serial.c']]],
  ['outchar1',['outChar1',['../pic24__uart_8c.html#aff55a8031fdfa5e4ceda1d5703d1b301',1,'outChar1(uint8_t u8_c):&#160;pic24_uart.c'],['../pic24__uart_8h.html#aff55a8031fdfa5e4ceda1d5703d1b301',1,'outChar1(uint8_t u8_c):&#160;pic24_uart.c']]],
  ['outcharxfer',['outCharXfer',['../data_xfer_8c.html#a59ad8961192dc303a4e14fcad256a32d',1,'outCharXfer(char c):&#160;dataXfer.c'],['../data_xfer_8h.html#a59ad8961192dc303a4e14fcad256a32d',1,'outCharXfer(char c):&#160;dataXfer.c']]],
  ['output_5fcmd_5fchar',['OUTPUT_CMD_CHAR',['../data_xfer_impl_8h.html#ab1a030fbdcdf0ee4ce1b32e17c892478a95c226c42fc66df08ce067b3d29b2d7a',1,'dataXferImpl.h']]],
  ['output_5fcmd_5fcmd',['OUTPUT_CMD_CMD',['../data_xfer_impl_8h.html#ab1a030fbdcdf0ee4ce1b32e17c892478a2b1010fe86752d63e23a355f97eca327',1,'dataXferImpl.h']]],
  ['output_5fcmd_5fnone',['OUTPUT_CMD_NONE',['../data_xfer_impl_8h.html#ab1a030fbdcdf0ee4ce1b32e17c892478a9f0b894e3dc50ff72279fce4265eabfa',1,'dataXferImpl.h']]],
  ['output_5fcmd_5frepeated_5fcmd',['OUTPUT_CMD_REPEATED_CMD',['../data_xfer_impl_8h.html#ab1a030fbdcdf0ee4ce1b32e17c892478ab01a98dae30c9d12b3f10fbffc6c164d',1,'dataXferImpl.h']]],
  ['output_5fcmd_5frepeated_5fwait',['OUTPUT_CMD_REPEATED_WAIT',['../data_xfer_impl_8h.html#ab1a030fbdcdf0ee4ce1b32e17c892478ab74bc03edf148af6da6794c80c1d2046',1,'dataXferImpl.h']]],
  ['outstring',['outString',['../pic24__serial_8c.html#a7a3a7f46bd5abfcb1ff2956face4d2c7',1,'outString(const char *psz_s):&#160;pic24_serial.c'],['../pic24__serial_8h.html#a7a3a7f46bd5abfcb1ff2956face4d2c7',1,'outString(const char *psz_s):&#160;pic24_serial.c']]],
  ['outuint16',['outUint16',['../pic24__serial_8c.html#a31903a701b2d823417fba4075f341797',1,'outUint16(uint16_t u16_x):&#160;pic24_serial.c'],['../pic24__serial_8h.html#a31903a701b2d823417fba4075f341797',1,'outUint16(uint16_t u16_x):&#160;pic24_serial.c']]],
  ['outuint16decimal',['outUint16Decimal',['../pic24__serial_8c.html#ae29a84425ba5596979457b7593c677b4',1,'outUint16Decimal(uint16_t u16_x):&#160;pic24_serial.c'],['../pic24__serial_8h.html#ae29a84425ba5596979457b7593c677b4',1,'outUint16Decimal(uint16_t u16_x):&#160;pic24_serial.c']]],
  ['outuint32',['outUint32',['../pic24__serial_8c.html#aea95c3873a304e85f3dd173a53f16c7e',1,'outUint32(uint32_t u32_x):&#160;pic24_serial.c'],['../pic24__serial_8h.html#aea95c3873a304e85f3dd173a53f16c7e',1,'outUint32(uint32_t u32_x):&#160;pic24_serial.c']]],
  ['outuint8',['outUint8',['../pic24__serial_8c.html#a6ca34e42dff5af3d0c929b7fbb36e385',1,'outUint8(uint8_t u8_x):&#160;pic24_serial.c'],['../pic24__serial_8h.html#a6ca34e42dff5af3d0c929b7fbb36e385',1,'outUint8(uint8_t u8_x):&#160;pic24_serial.c']]],
  ['outuint8decimal',['outUint8Decimal',['../pic24__serial_8c.html#aea03c9842152ec1111ec695163b6667d',1,'outUint8Decimal(uint8_t u8_x):&#160;pic24_serial.c'],['../pic24__serial_8h.html#aea03c9842152ec1111ec695163b6667d',1,'outUint8Decimal(uint8_t u8_x):&#160;pic24_serial.c']]]
];
