var searchData=
[
  ['esos_5fcomm_5fbuff_5fdsc',['ESOS_COMM_BUFF_DSC',['../struct_e_s_o_s___c_o_m_m___b_u_f_f___d_s_c.html',1,'']]],
  ['esos_5ftask_5fhandle',['ESOS_TASK_HANDLE',['../struct_e_s_o_s___t_a_s_k___h_a_n_d_l_e.html',1,'']]]
];
