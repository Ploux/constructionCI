var searchData=
[
  ['xfer_5fvar',['XFER_VAR',['../struct_x_f_e_r___v_a_r.html',1,'']]]
];
