var searchData=
[
  ['var_5fsize_5fbits',['VAR_SIZE_BITS',['../data_xfer_impl_8h.html#a34a5d6a262f96f509ebba2a579dc864e',1,'dataXferImpl.h']]],
  ['var_5fsize_5fmask',['VAR_SIZE_MASK',['../data_xfer_impl_8h.html#a389d8066f3429d0455b6732edb2669b8',1,'dataXferImpl.h']]]
];
