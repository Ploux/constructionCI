var searchData=
[
  ['get_5fosc_5fsel_5fbits',['GET_OSC_SEL_BITS',['../pic24__clockfreq_8h.html#a5fbef09c59f551f99c1a79e3dff1b72f',1,'pic24_clockfreq.h']]],
  ['gettimerprescale',['getTimerPrescale',['../pic24__timer_8h.html#a33f8bb23d793df5a63d3b761c0368bf7',1,'pic24_timer.h']]]
];
