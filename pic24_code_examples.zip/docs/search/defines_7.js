var searchData=
[
  ['hardmapped_5fuart',['HARDMAPPED_UART',['../pic24__libconfig_8h.html#afbe392695cc82726fa7b8e6c640fd46c',1,'pic24_libconfig.h']]],
  ['hardware_5fplatform',['HARDWARE_PLATFORM',['../pic24__libconfig_8h.html#a36bfbb43cadf0907ba370d838ee04f35',1,'pic24_libconfig.h']]],
  ['hb_5fled',['HB_LED',['../pic24__libconfig_8h.html#a0d4ea42e869b9fb2c701c39eef45be3a',1,'pic24_libconfig.h']]],
  ['heartbeat_5fmax',['HEARTBEAT_MAX',['../pic24__util_8c.html#a616605d2fdd6e20f985c8b08de8c0535',1,'pic24_util.c']]]
];
