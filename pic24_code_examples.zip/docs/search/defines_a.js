var searchData=
[
  ['max_5fnum_5fchild_5ftasks',['MAX_NUM_CHILD_TASKS',['../esos_8h.html#a83e8d97ef5684ebd1a15bd3e7c927b62',1,'esos.h']]],
  ['max_5fnum_5fxfer_5fvars',['MAX_NUM_XFER_VARS',['../data_xfer_impl_8h.html#a3d14a9fcd9a82c542d41517ceffcd61c',1,'dataXferImpl.h']]],
  ['microstick2',['MICROSTICK2',['../pic24__libconfig_8h.html#a907181d5d566808c0c9fea70cac1f515',1,'pic24_libconfig.h']]],
  ['ms_5fper_5fheartbeat',['MS_PER_HEARTBEAT',['../pic24__util_8c.html#a6117bd5a7ac4d5eada9969f45d1544fa',1,'pic24_util.c']]],
  ['msb',['MSB',['../all__generic_8h.html#a9c836be4f9864747a0b7cbc120b07454',1,'all_generic.h']]]
];
