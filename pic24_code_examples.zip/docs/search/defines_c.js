var searchData=
[
  ['ok',['OK',['../all__generic_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'all_generic.h']]],
  ['osc_5fsel_5fbits',['OSC_SEL_BITS',['../pic24__clockfreq_8h.html#a48cc82e45d755fb067ec21ad11b97f03',1,'pic24_clockfreq.h']]]
];
