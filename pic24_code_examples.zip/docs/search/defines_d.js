var searchData=
[
  ['posc_5ffreq',['POSC_FREQ',['../pic24__clockfreq_8h.html#a55d00dbdccbb312030edd1e71696d0e1',1,'pic24_clockfreq.h']]],
  ['poscmd_5fsel',['POSCMD_SEL',['../pic24__clockfreq_8h.html#ae88e4fd6fa9afb924690935d4092baaf',1,'pic24_clockfreq.h']]]
];
