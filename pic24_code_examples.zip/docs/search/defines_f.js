var searchData=
[
  ['serial_5feol_5fcr',['SERIAL_EOL_CR',['../pic24__libconfig_8h.html#aab68599d3deba38c78321e84488f6fdd',1,'pic24_libconfig.h']]],
  ['serial_5feol_5fcr_5flf',['SERIAL_EOL_CR_LF',['../pic24__libconfig_8h.html#a192d1cc2c374d21f49f98711f1eb2c03',1,'pic24_libconfig.h']]],
  ['serial_5feol_5fdefault',['SERIAL_EOL_DEFAULT',['../pic24__libconfig_8h.html#abda3b56a9b2df150ed2b558e7beb4ec7',1,'pic24_libconfig.h']]],
  ['serial_5feol_5flf',['SERIAL_EOL_LF',['../pic24__libconfig_8h.html#aaba16dccc514a9ded6f05a80b555fec6',1,'pic24_libconfig.h']]],
  ['short_5fvar_5fmax_5flen',['SHORT_VAR_MAX_LEN',['../data_xfer_impl_8h.html#a9a5bb32dd8c606071c3c6686458e3b96',1,'dataXferImpl.h']]],
  ['sim_5fclock',['SIM_CLOCK',['../pic24__clockfreq_8h.html#aa276553dfc62bbb7cd17dc25a0a60cf3',1,'pic24_clockfreq.h']]],
  ['sleep',['SLEEP',['../pic24__chip_8h.html#a22f3294c370608bd18b0123c299b3df7',1,'pic24_chip.h']]],
  ['specify_5fvar',['SPECIFY_VAR',['../data_xfer_8h.html#a9fe8ee550860f771452a32777eb99ccb',1,'dataXfer.h']]],
  ['starter_5fboard_5f28p',['STARTER_BOARD_28P',['../pic24__libconfig_8h.html#a159c367dc2ebd8ad7aa6ebc0c634df67',1,'pic24_libconfig.h']]]
];
