var searchData=
[
  ['bool',['BOOL',['../all__generic_8h.html#a3e5b8192e7d9ffaf3542f1210aec18dd',1,'all_generic.h']]]
];
