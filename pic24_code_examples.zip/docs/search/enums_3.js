var searchData=
[
  ['receive_5ferror',['RECEIVE_ERROR',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35',1,'dataXferImpl.h']]],
  ['receive_5fstate',['RECEIVE_STATE',['../data_xfer_impl_8h.html#a2a0cb6e5359e1dbd57e7d9c5f7553175',1,'dataXferImpl.h']]]
];
