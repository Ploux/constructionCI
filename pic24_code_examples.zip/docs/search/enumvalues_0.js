var searchData=
[
  ['err_5findex_5ftoo_5fhigh',['ERR_INDEX_TOO_HIGH',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35a4091145e664bb13023f7735bd5b3502a',1,'dataXferImpl.h']]],
  ['err_5finterrupted_5fcmd',['ERR_INTERRUPTED_CMD',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35a72c58c413381361691654fcbd7b07c99',1,'dataXferImpl.h']]],
  ['err_5fmicrocontroller_5fvar_5fspec',['ERR_MICROCONTROLLER_VAR_SPEC',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35adfc4d797dc524dbc9395cb96af6fc0a8',1,'dataXferImpl.h']]],
  ['err_5fnone',['ERR_NONE',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35a5203071ca85e00df6bf2526855b6df0d',1,'dataXferImpl.h']]],
  ['err_5fread_5fonly_5fvar',['ERR_READ_ONLY_VAR',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35aeabc553354b0b90a3d4c9f7117ec85da',1,'dataXferImpl.h']]],
  ['err_5frepeated_5fcmd',['ERR_REPEATED_CMD',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35a77d7e55d0946e5a98eaccaeb1e2337ff',1,'dataXferImpl.h']]],
  ['err_5ftimeout',['ERR_TIMEOUT',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35ac568baeb6407ef5e2630084ccbc34be8',1,'dataXferImpl.h']]],
  ['err_5funspecified_5findex',['ERR_UNSPECIFIED_INDEX',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35a26004f2f1c3567b3a01cfc9435f0af4b',1,'dataXferImpl.h']]],
  ['err_5fvar_5fsize_5fmismatch',['ERR_VAR_SIZE_MISMATCH',['../data_xfer_impl_8h.html#a52e92fbc847f630acac0efda8b4cfe35a2ef01463d8749f58ce891c9fd09705ad',1,'dataXferImpl.h']]]
];
