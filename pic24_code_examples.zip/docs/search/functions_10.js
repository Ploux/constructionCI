var searchData=
[
  ['user_5finit',['user_init',['../esos_8h.html#aa8253cd89ed4b268472ed62f4f2074ae',1,'user_init(void):&#160;app_ecan_receiver.c'],['../app__timer_8c.html#aa8253cd89ed4b268472ed62f4f2074ae',1,'user_init(void):&#160;app_timer.c']]],
  ['ustou16ticks',['usToU16Ticks',['../pic24__timer_8c.html#a088c81fa40668ca18914244b10d70f95',1,'usToU16Ticks(uint16_t u16_us, uint16_t u16_pre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#a088c81fa40668ca18914244b10d70f95',1,'usToU16Ticks(uint16_t u16_us, uint16_t u16_pre):&#160;pic24_timer.c']]],
  ['ustou32ticks',['usToU32Ticks',['../pic24__timer_8c.html#a696306a12d320b821a5e5fb1e46de751',1,'usToU32Ticks(uint32_t u32_us, uint16_t u16_pre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#a696306a12d320b821a5e5fb1e46de751',1,'usToU32Ticks(uint32_t u32_us, uint16_t u16_pre):&#160;pic24_timer.c']]]
];
