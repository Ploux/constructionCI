var searchData=
[
  ['validateindex',['validateIndex',['../data_xfer_impl_8c.html#a245c0885e3451df15d905759e9eb6172',1,'dataXferImpl.c']]],
  ['validatelength',['validateLength',['../data_xfer_impl_8c.html#aa1f92991d56fde2cb8d5f4ec7f7599ca',1,'dataXferImpl.c']]]
];
