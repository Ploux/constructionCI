var searchData=
[
  ['delayandupdateheartbeatcount',['delayAndUpdateHeartbeatCount',['../pic24__delay_8h.html#a9206475f7e2a2e81237ff3e91f63dd2c',1,'pic24_delay.h']]],
  ['doerasepageflash',['doErasePageFlash',['../pic24__flash_8c.html#aa7b1f94d18da54a99edcefbf9f2bbf30',1,'pic24_flash.c']]],
  ['doheartbeat',['doHeartbeat',['../pic24__util_8c.html#a6ec988b2aa566e75a8c7bdff4be72865',1,'doHeartbeat(void):&#160;pic24_util.c'],['../pic24__util_8h.html#a6ec988b2aa566e75a8c7bdff4be72865',1,'doHeartbeat(void):&#160;pic24_util.c']]],
  ['doreadlatchflash',['doReadLatchFlash',['../pic24__flash_8c.html#af82d14a4766b610c7d022409769ead42',1,'doReadLatchFlash(uint16_t u16_addrhi, uint16_t u16_addrlo):&#160;pic24_flash.c'],['../pic24__flash_8h.html#af82d14a4766b610c7d022409769ead42',1,'doReadLatchFlash(uint16_t u16_addrhi, uint16_t u16_addrlo):&#160;pic24_flash.c']]],
  ['doreadpageflash',['doReadPageFlash',['../pic24__flash_8c.html#a1e6548b93e966ccfee5c1c5b7a345108',1,'doReadPageFlash(union32 u32_pmemAddress, uint8_t *pu8_data, uint16_t u16_len):&#160;pic24_flash.c'],['../pic24__flash_8h.html#a1e6548b93e966ccfee5c1c5b7a345108',1,'doReadPageFlash(union32 u32_pmemAddress, uint8_t *pu8_data, uint16_t u16_len):&#160;pic24_flash.c']]],
  ['dowritelatchflash',['doWriteLatchFlash',['../pic24__flash_8c.html#a1561bf36dc519cb692b791f5c2dfcee7',1,'doWriteLatchFlash(uint16_t u16_addrhi, uint16_t u16_addrlo, uint16_t u16_wordhi, uint16_t u16_wordlo):&#160;pic24_flash.c'],['../pic24__flash_8h.html#a1561bf36dc519cb692b791f5c2dfcee7',1,'doWriteLatchFlash(uint16_t u16_addrhi, uint16_t u16_addrlo, uint16_t u16_wordhi, uint16_t u16_wordlo):&#160;pic24_flash.c']]],
  ['dowritepageflash',['doWritePageFlash',['../pic24__flash_8c.html#a047c889478af000169ddad395545209f',1,'doWritePageFlash(union32 u32_pmemAddress, uint8_t *pu8_data, uint16_t u16_len):&#160;pic24_flash.c'],['../pic24__flash_8h.html#a047c889478af000169ddad395545209f',1,'doWritePageFlash(union32 u32_pmemAddress, uint8_t *pu8_data, uint16_t u16_len):&#160;pic24_flash.c']]],
  ['dowriterowflash',['doWriteRowFlash',['../pic24__flash_8c.html#a3347e2d0920215beb24161afea88c3e2',1,'pic24_flash.c']]]
];
