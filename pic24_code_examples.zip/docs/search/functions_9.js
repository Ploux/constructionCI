var searchData=
[
  ['mstou16ticks',['msToU16Ticks',['../pic24__timer_8c.html#aa2b459a5ab40167228c2ab6369fee878',1,'msToU16Ticks(uint16_t u16_ms, uint16_t u16_pre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#aa2b459a5ab40167228c2ab6369fee878',1,'msToU16Ticks(uint16_t u16_ms, uint16_t u16_pre):&#160;pic24_timer.c']]]
];
