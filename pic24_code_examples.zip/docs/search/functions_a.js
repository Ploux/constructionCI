var searchData=
[
  ['notifyoftimeout',['notifyOfTimeout',['../data_xfer_impl_8c.html#ae347b3bdd40465fab8ba2fb3975a74d4',1,'notifyOfTimeout():&#160;dataXferImpl.c'],['../data_xfer_impl_8h.html#ae347b3bdd40465fab8ba2fb3975a74d4',1,'notifyOfTimeout():&#160;dataXferImpl.c']]]
];
