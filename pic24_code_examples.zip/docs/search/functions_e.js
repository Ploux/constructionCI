var searchData=
[
  ['sendvar',['sendVar',['../data_xfer_8c.html#ac6168d273a011397bd3443acc52a9be4',1,'sendVar(uint u_varIndex):&#160;dataXfer.c'],['../data_xfer_8h.html#ac6168d273a011397bd3443acc52a9be4',1,'sendVar(uint u_varIndex):&#160;dataXfer.c']]],
  ['specifyvar',['specifyVar',['../data_xfer_8c.html#a5295a0d929d0eb046e729106e54fa9b1',1,'specifyVar(uint u_varIndex, volatile void *pv_data, uint u_size, BOOL b_isWriteable, char *psz_format, char *psz_name, char *psz_desc):&#160;dataXfer.c'],['../data_xfer_8h.html#a5295a0d929d0eb046e729106e54fa9b1',1,'specifyVar(uint u_varIndex, volatile void *pv_data, uint u_size, BOOL b_isWriteable, char *psz_format, char *psz_name, char *psz_desc):&#160;dataXfer.c']]],
  ['starti2c1',['startI2C1',['../pic24__i2c_8c.html#acd68199d0e11d29b887da48f406db7c5',1,'startI2C1(void):&#160;pic24_i2c.c'],['../pic24__i2c_8h.html#acd68199d0e11d29b887da48f406db7c5',1,'startI2C1(void):&#160;pic24_i2c.c']]],
  ['starttxecan1',['startTxECAN1',['../pic24__ecan_8c.html#a62fb3d66840cc7c4f4fc3fdb6f463f22',1,'pic24_ecan.c']]],
  ['stdioopen',['stdioOpen',['../pic24__stdio__uart_8c.html#aedcece0d2ff2c5a79f3c3e7b46ccacfa',1,'pic24_stdio_uart.c']]],
  ['stepcommandfindmachine',['stepCommandFindMachine',['../data_xfer_impl_8c.html#a6f26709dd9173df6129d3332c3b5439e',1,'stepCommandFindMachine(char c_inChar, char *c_outChar):&#160;dataXferImpl.c'],['../data_xfer_impl_8h.html#a6f26709dd9173df6129d3332c3b5439e',1,'stepCommandFindMachine(char c_inChar, char *c_outChar):&#160;dataXferImpl.c']]],
  ['stepreceivemachine',['stepReceiveMachine',['../data_xfer_impl_8c.html#ae8fbdae3e9769dd9e976d419271d01f9',1,'stepReceiveMachine(char c_inChar):&#160;dataXferImpl.c'],['../data_xfer_impl_8h.html#ae8fbdae3e9769dd9e976d419271d01f9',1,'stepReceiveMachine(char c_inChar):&#160;dataXferImpl.c']]],
  ['stopi2c1',['stopI2C1',['../pic24__i2c_8c.html#a82fa899c287ed3b97750cefb51674c5b',1,'stopI2C1(void):&#160;pic24_i2c.c'],['../pic24__i2c_8h.html#a82fa899c287ed3b97750cefb51674c5b',1,'stopI2C1(void):&#160;pic24_i2c.c']]],
  ['switchclock',['switchClock',['../pic24__clockfreq_8c.html#ab9c35fde2312f6d6cd882492a2e59ff1',1,'switchClock(uint8_t u8_source):&#160;pic24_clockfreq.c'],['../pic24__clockfreq_8h.html#ab9c35fde2312f6d6cd882492a2e59ff1',1,'switchClock(uint8_t u8_source):&#160;pic24_clockfreq.c']]]
];
