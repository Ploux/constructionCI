var searchData=
[
  ['tickstoms',['ticksToMs',['../pic24__timer_8c.html#ad59b90bbfe03bd6d6cea4c41c5be5079',1,'ticksToMs(uint32_t u32_ticks, uint16_t u16_tmrPre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#ad59b90bbfe03bd6d6cea4c41c5be5079',1,'ticksToMs(uint32_t u32_ticks, uint16_t u16_tmrPre):&#160;pic24_timer.c']]],
  ['tickstons',['ticksToNs',['../pic24__timer_8c.html#a27ea65c0f8f5de071ca5e99e0578d253',1,'ticksToNs(uint32_t u32_ticks, uint16_t u16_tmrPre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#a27ea65c0f8f5de071ca5e99e0578d253',1,'ticksToNs(uint32_t u32_ticks, uint16_t u16_tmrPre):&#160;pic24_timer.c']]],
  ['tickstous',['ticksToUs',['../pic24__timer_8c.html#ae6cc60494d0e6721bb6df25c311ad47e',1,'ticksToUs(uint32_t u32_ticks, uint16_t u16_tmrPre):&#160;pic24_timer.c'],['../pic24__timer_8h.html#ae6cc60494d0e6721bb6df25c311ad47e',1,'ticksToUs(uint32_t u32_ticks, uint16_t u16_tmrPre):&#160;pic24_timer.c']]],
  ['toggleheartbeat',['toggleHeartbeat',['../pic24__util_8c.html#ac8b83e52a126f1fcbfbc3a4f574e249e',1,'toggleHeartbeat(void):&#160;pic24_util.c'],['../pic24__util_8h.html#ac8b83e52a126f1fcbfbc3a4f574e249e',1,'toggleHeartbeat(void):&#160;pic24_util.c']]]
];
