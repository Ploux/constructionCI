var searchData=
[
  ['history_20and_20release_20notes_20for_20this_20library_20collection_2e',['History and release notes for this library collection.',['../history.html',1,'']]]
];
