var searchData=
[
  ['uint',['uint',['../data_xfer_impl_8h.html#a91ad9478d81a7aaf2593e8d9c3d06a14',1,'dataXferImpl.h']]],
  ['uint8_5ft',['uint8_t',['../data_xfer_impl_8h.html#aba7bc1797add20fe3efdf37ced1182c5',1,'dataXferImpl.h']]]
];
