var searchData=
[
  ['apsz_5ferrordesc',['apsz_errorDesc',['../data_xfer_impl_8c.html#a8a06aa0592b5b514deab5e582507e5af',1,'dataXferImpl.c']]],
  ['au8_5fvarspecdata',['au8_varSpecData',['../data_xfer_impl_8c.html#ad858bd51655d341c0695077c09bf3419',1,'dataXferImpl.c']]],
  ['au8_5fxfervarwriteable',['au8_xferVarWriteable',['../data_xfer_impl_8c.html#acfba839d6ee5b8500fa253a74bc32944',1,'au8_xferVarWriteable():&#160;dataXferImpl.c'],['../data_xfer_impl_8h.html#acfba839d6ee5b8500fa253a74bc32944',1,'au8_xferVarWriteable():&#160;dataXferImpl.c']]]
];
