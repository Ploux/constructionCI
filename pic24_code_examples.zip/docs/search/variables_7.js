var searchData=
[
  ['psz_5fdesc',['psz_desc',['../struct_x_f_e_r___v_a_r.html#a564febe7e468bbb148b6601c9e640dc4',1,'XFER_VAR']]],
  ['psz_5fformat',['psz_format',['../struct_x_f_e_r___v_a_r.html#a9316961a417a5569b1fb694532b97b4e',1,'XFER_VAR']]],
  ['psz_5fname',['psz_name',['../struct_x_f_e_r___v_a_r.html#ac98b73512f3c37c16bd49af9127e6912',1,'XFER_VAR']]],
  ['pu8_5fdata',['pu8_data',['../struct_x_f_e_r___v_a_r.html#a760a3a183021bb77e7d5ab0e3ce6a8e9',1,'XFER_VAR']]]
];
