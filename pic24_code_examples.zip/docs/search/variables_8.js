var searchData=
[
  ['receiveerror',['receiveError',['../data_xfer_impl_8c.html#aac10772775ea33278bfd60754885b499',1,'dataXferImpl.c']]],
  ['receivestate',['receiveState',['../data_xfer_impl_8c.html#a30e0e7e542165f8f103fbab152050dc6',1,'dataXferImpl.c']]]
];
