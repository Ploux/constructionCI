var searchData=
[
  ['sz_5flasterror',['sz_lastError',['../pic24__util_8c.html#ab001130c6b90f639976282207ca63169',1,'pic24_util.c']]],
  ['sz_5flasttimeouterror',['sz_lastTimeoutError',['../pic24__util_8c.html#acd39b4d108f530da976f250e7304f692',1,'sz_lastTimeoutError():&#160;pic24_util.c'],['../pic24__util_8h.html#acd39b4d108f530da976f250e7304f692',1,'sz_lastTimeoutError():&#160;pic24_util.c']]]
];
