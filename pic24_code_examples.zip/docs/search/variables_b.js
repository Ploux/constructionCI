var searchData=
[
  ['xfervar',['xferVar',['../data_xfer_impl_8c.html#ac0a9a04ad6199a5de64bdbe7bf26dcef',1,'xferVar():&#160;dataXferImpl.c'],['../data_xfer_impl_8h.html#ac0a9a04ad6199a5de64bdbe7bf26dcef',1,'xferVar():&#160;dataXferImpl.c']]]
];
