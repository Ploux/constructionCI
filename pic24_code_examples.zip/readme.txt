All documentation is contained in docs/index.html. Please refer to that file
for more information.
